from functools import reduce
from operator import mul

# class Tree(object):
#     def __init__(self,value,left=None,right=None):
#         self.value = value
#         self.left = left
#         self.right = right
#
#
#     def __str__(self):
#         if self:
#             s = ""
#             if self.left is not None:
#                 s += f"{self.left},"
#             s += f"{self.value}"
#             if self.right is not None:
#                 s += f",{self.right}"
#             return f"({s})"
#         return f"( , , )"


# t4 = Tree(2)
# t5 = Tree(5)
# t1 = Tree(1, None, t4)
# t2 = Tree(4, t5)
# t3 = Tree(3, t1, t2)
# print(t3)



# def f1(x1,x2):
#     def f2 (y,x3):
#         return (x3+x1)*y
#     return lambda x: f2(x-2,x2)
#
# def f3(a,b,c):
#     f4 = lambda y: y+1
#     b = 5
#     c = f4(a)
#     f4 = lambda y,b: y+b+a
#     return f4(c,a)
#
# # f1(3,6)f3(1,2,3)
#
# print(f"{f1(3,6)(f3(1,2,3))}")


# def f(x=3):
#     y=f(x)
#     def h():
#         if(callable(x)):
#             return x(y)
#         return y+x
#     return h
# g=f(lambda x: x+1)
# print(g)

# def sq(x):
#     return x*x
#
# def call(fn,n):
#     return fn(n)
# n=14
# call(sq,n-3)
# print(call(sq,n-3))

names = (-1,2,-3,4,-5)
noa = sum(map(abs,names))

print((reduce(mul,(1,2,3,4,5))))
